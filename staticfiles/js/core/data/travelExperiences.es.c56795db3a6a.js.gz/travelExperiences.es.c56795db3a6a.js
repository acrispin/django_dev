﻿[
    {
        codigo: "1",
        experience: "Nuestro viaje a Peru",
        date: "15/12/2014",
        customer: "Maria Teresa Tronco",
        country: "Mexico"
    },
    {
        codigo: "2",
        experience: "Una experiencia única",
        date: "19/11/2014",
        customer: "Melina Olvera",
        country: "Mexico"
    },
    {
        codigo: "3",
        experience: "Peru es increible",
        date: "23/10/2014",
        customer: "Carmen Brito",
        country: "Venezuela"
    },
    {
        codigo: "4",
        experience: "Excelencia de Servicio",
        date: "23/10/2014",
        customer: "Maria Oliver-hoyo",
        country: "U.S.A"
    },
    {
        codigo: "5",
        experience: "Peru",
        date: "06/10/2014",
        customer: "Jose Maria Morote",
        country: "España"
    }
]