﻿[
    {
        codigo: "1",
        country: "USA",
        phone: "1-866-735-6459"
    },
    {
        codigo: "2",
        country: "Canadá",
        phone: "1-866-953-4089"
    },
    {
        codigo: "3",
        country: "UK",
        phone: "0-808-234-3271"
    },
    {
        codigo: "4",
        country: "MEXICO",
        phone: "0-800-123-7039"
    },
    {
        codigo: "5",
        country: "SPAIN",
        phone: "900995105"
    }
]