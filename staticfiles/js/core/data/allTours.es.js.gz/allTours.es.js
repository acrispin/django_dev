﻿[
    {
        codigo: "1",
        name: "Cusco y Machu Picchu",
        days: "7",
        flagbest: true
    },
    {
        codigo: "2",
        name: "Machu Picchu y Lago Titicaca",
        days: "9",
        flagbest: true
    },
    {
        codigo: "3",
        name: "Machu Picchu y El Amazonas",
        days: "10",
        flagbest: true
    },
    {
        codigo: "4",
        name: "Camino Inca a Machu Picchu",
        days: "10",
        flagbest: true
    },
    {
        codigo: "5",
        name: "Machu Picchu y Nazca",
        days: "9",
        flagbest: true
    },
    {
        codigo: "6",
        name: "De los Andes a la Selva Tropical",
        days: "14"
    },
    {
        codigo: "7",
        name: "Perú Total",
        days: "20"
    },
    {
        codigo: "8",
        name: "Machu Picchu y la Selva Tropical",
        days: "9"
    },
    {
        codigo: "9",
        name: "Maravillas de Perú y Bolivia",
        days: "11"
    },
    {
        codigo: "10",
        name: "Perú y Chile",
        days: "13"
    },
    {
        codigo: "11",
        name: "Perú y Ecuador",
        days: "14"
    }
]