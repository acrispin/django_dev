﻿[
    {
        codigo: "1",
        name: "Cusco and Machu Picchu",
        days: "8",
        flagbest: true
    },
    {
        codigo: "2",
        name: "Machu Picchu and Titicaca Lake",
        days: "10",
        flagbest: true
    },
    {
        codigo: "3",
        name: "Machu Picchu and The Amazon",
        days: "12",
        flagbest: true
    },
    {
        codigo: "4",
        name: "Inca Trail to Machu Picchu",
        days: "12",
        flagbest: true
    },
    {
        codigo: "5",
        name: "Machu Picchu and Nasca",
        days: "9",
        flagbest: true
    },
    {
        codigo: "6",
        name: "From the Andes to the Rainforest",
        days: "14"
    },
    {
        codigo: "7",
        name: "Total Peru",
        days: "21"
    },
    {
        codigo: "8",
        name: "Machu Picchu and Rainforest",
        days: "10"
    },
    {
        codigo: "9",
        name: "Wonders of Peru and Bolivia",
        days: "14"
    },
    {
        codigo: "10",
        name: "Peru and Chile",
        days: "15"
    },
    {
        codigo: "11",
        name: "Peru and Ecuador",
        days: "14"
    }
]