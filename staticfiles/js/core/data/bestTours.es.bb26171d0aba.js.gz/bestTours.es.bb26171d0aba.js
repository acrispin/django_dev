﻿[
    {
        codigo: "1",
        name: "Cusco y Machu Picchu",
        days: "7",
        image: "520.jpg",
        alt: "Machu Picchu",
        title: "Machu Picchu"
    },
    {
        codigo: "2",
        name: "Machu Picchu y el Lago Titicaca",
        days: "9",
        image: "titicaca1.jpg",
        alt: "Lago Titicaca",
        title: "Lago Titicaca"
    },
    {
        codigo: "3",
        name: "Machu Picchu y el Amazonas",
        days: "10",
        image: "amazon_river_8344.jpg",
        alt: "El Amazonas",
        title: "El Amazonas"
    },
    {
        codigo: "4",
        name: "Camino Inca a Machu Picchu",
        days: "10",
        image: "Inca-Trail-Peru.jpg",
        alt: "Camino Inca",
        title: "Camino Inca"
    },
    {
        codigo: "5",
        name: "Machu Picchu y Nazca",
        days: "9",
        image: "images.jpg",
        alt: "Nazca",
        title: "Nazca"
    }
]