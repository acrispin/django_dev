﻿[
    {
        codigo: "1",
        name: "Cusco and Machu Picchu",
        days: "8",
        image: "520.jpg",
        alt: "Machu Picchu",
        title: "Machu Picchu"
    },
    {
        codigo: "2",
        name: "Machu Picchu and Titicaca Lake",
        days: "10",
        image: "titicaca1.jpg",
        alt: "Titicaca Lake",
        title: "Titicaca Lake"
    },
    {
        codigo: "3",
        name: "Machu Picchu and The Amazon",
        days: "12",
        image: "amazon_river_8344.jpg",
        alt: "The Amazon",
        title: "The Amazon"
    },
    {
        codigo: "4",
        name: "Inca Trail to Machu Picchu",
        days: "12",
        image: "Inca-Trail-Peru.jpg",
        alt: "Inca Trail",
        title: "Inca Trail"
    },
    {
        codigo: "5",
        name: "Machu Picchu and Nasca",
        days: "9",
        image: "images.jpg",
        alt: "Nasca",
        title: "Nasca"
    }
]